package com.encapital.io.banksmsapp.utils;

import android.os.Environment;

public class Config {
    public static final String CRASH_DIR= Environment.getExternalStorageDirectory() + "/bankSMS_crash/";
    public static final String EXCEPTION_DIR= Environment.getExternalStorageDirectory() + "/bankSMS_exception/";

}
